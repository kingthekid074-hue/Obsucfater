## Packages
@monaco-editor/react | Code editor component
framer-motion | Animations for the "hacking" effects
clsx | Class name utility (likely already installed but good to ensure)
tailwind-merge | Class merging (likely already installed)
lucide-react | Icons (already in base but vital)

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  mono: ["'JetBrains Mono'", "'Fira Code'", "monospace"],
  sans: ["'Inter'", "sans-serif"],
  display: ["'Space Grotesk'", "sans-serif"],
}
colors:
  cyber: {
    DEFAULT: "#00ff41",
    dim: "#008F11",
    dark: "#0d0208",
  }
