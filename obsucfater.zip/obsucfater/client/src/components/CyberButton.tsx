import React from "react";
import { cn } from "@/lib/utils";
import { Loader2 } from "lucide-react";

interface CyberButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  isLoading?: boolean;
  variant?: "primary" | "secondary" | "danger";
  icon?: React.ReactNode;
}

export function CyberButton({ 
  children, 
  className, 
  isLoading, 
  variant = "primary", 
  icon,
  disabled,
  ...props 
}: CyberButtonProps) {
  const variants = {
    primary: "bg-primary/10 border-primary text-primary hover:bg-primary hover:text-black hover:shadow-[0_0_15px_rgba(0,255,65,0.4)]",
    secondary: "bg-transparent border-muted-foreground/30 text-muted-foreground hover:border-primary/50 hover:text-primary",
    danger: "bg-destructive/10 border-destructive text-destructive hover:bg-destructive hover:text-white"
  };

  return (
    <button
      disabled={disabled || isLoading}
      className={cn(
        "relative overflow-hidden px-6 py-3 border font-mono font-bold text-sm tracking-wider uppercase transition-all duration-200",
        "disabled:opacity-50 disabled:cursor-not-allowed",
        "group flex items-center justify-center gap-2",
        variants[variant],
        className
      )}
      {...props}
    >
      {/* Corner decorations */}
      <span className="absolute top-0 left-0 w-1 h-1 bg-current opacity-50 group-hover:w-2 group-hover:h-2 transition-all" />
      <span className="absolute bottom-0 right-0 w-1 h-1 bg-current opacity-50 group-hover:w-2 group-hover:h-2 transition-all" />
      
      {isLoading ? (
        <>
          <Loader2 className="w-4 h-4 animate-spin" />
          <span>PROCESSING...</span>
        </>
      ) : (
        <>
          {icon && <span className="w-4 h-4">{icon}</span>}
          {children}
        </>
      )}
    </button>
  );
}
