import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Info } from "lucide-react";
import { cn } from "@/lib/utils";

interface OptionToggleProps {
  id: string;
  label: string;
  description?: string;
  checked: boolean;
  onCheckedChange: (checked: boolean) => void;
  disabled?: boolean;
}

export function OptionToggle({
  id,
  label,
  description,
  checked,
  onCheckedChange,
  disabled
}: OptionToggleProps) {
  return (
    <div className={cn(
      "flex items-center justify-between p-3 rounded bg-card/40 border border-transparent hover:border-primary/20 transition-colors",
      checked && "bg-primary/5 border-primary/30"
    )}>
      <div className="flex items-center gap-2">
        <Label htmlFor={id} className="font-mono text-sm cursor-pointer select-none">
          {label}
        </Label>
        {description && (
          <Tooltip>
            <TooltipTrigger asChild>
              <Info className="w-3.5 h-3.5 text-muted-foreground/70 hover:text-primary transition-colors cursor-help" />
            </TooltipTrigger>
            <TooltipContent className="bg-slate-900 border border-primary/20 text-xs font-mono max-w-[250px]">
              <p>{description}</p>
            </TooltipContent>
          </Tooltip>
        )}
      </div>
      <Switch 
        id={id} 
        checked={checked} 
        onCheckedChange={onCheckedChange} 
        disabled={disabled}
        className="data-[state=checked]:bg-primary"
      />
    </div>
  );
}
