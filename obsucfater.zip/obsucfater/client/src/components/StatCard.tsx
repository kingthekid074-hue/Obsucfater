import { cn } from "@/lib/utils";

interface StatCardProps {
  label: string;
  value: string | number;
  className?: string;
  delay?: number;
}

export function StatCard({ label, value, className }: StatCardProps) {
  return (
    <div className={cn("flex flex-col p-4 bg-card/30 border border-border/50 rounded-sm hover:border-primary/30 transition-colors", className)}>
      <span className="text-xs text-muted-foreground font-mono uppercase tracking-widest mb-1">{label}</span>
      <span className="text-2xl font-bold font-display text-primary tracking-tight">{value}</span>
    </div>
  );
}
