import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import type { ObfuscationOptions, ObfuscationResponse } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function useObfuscate() {
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (options: ObfuscationOptions) => {
      // Small artificial delay for the "hacking" effect if response is too fast
      const startTime = Date.now();
      
      const res = await fetch(api.obfuscator.process.path, {
        method: api.obfuscator.process.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(options),
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.message || "Obfuscation failed");
      }

      const data = await res.json();
      const parsed = api.obfuscator.process.responses[200].safeParse(data);
      
      if (!parsed.success) {
        console.error("Validation failed:", parsed.error);
        throw new Error("Invalid response from server");
      }
      
      // Ensure at least 800ms animation
      const elapsed = Date.now() - startTime;
      if (elapsed < 800) {
        await new Promise(resolve => setTimeout(resolve, 800 - elapsed));
      }

      return parsed.data;
    },
    onError: (error: Error) => {
      toast({
        title: "SYSTEM ERROR",
        description: error.message,
        variant: "destructive",
        className: "border-red-500 font-mono"
      });
    }
  });
}

export function useObfuscationStats() {
  return useQuery({
    queryKey: [api.obfuscator.stats.path],
    queryFn: async () => {
      const res = await fetch(api.obfuscator.stats.path);
      if (!res.ok) throw new Error("Failed to fetch stats");
      const data = await res.json();
      return api.obfuscator.stats.responses[200].parse(data);
    },
    refetchInterval: 30000, // Refresh every 30s
  });
}
