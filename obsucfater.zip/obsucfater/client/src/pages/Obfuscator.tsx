import React, { useState } from "react";
import Editor, { type OnMount } from "@monaco-editor/react";
import { useObfuscate, useObfuscationStats } from "@/hooks/use-obfuscator";
import type { ObfuscationOptions } from "@shared/schema";
import { CyberButton } from "@/components/CyberButton";
import { OptionToggle } from "@/components/OptionToggle";
import { StatCard } from "@/components/StatCard";
import { 
  Shield, 
  Code2, 
  Cpu, 
  Fingerprint, 
  Download, 
  Play, 
  Terminal, 
  Layers, 
  Ghost,
  Lock,
  Zap,
  RefreshCw
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

export default function Obfuscator() {
  const [code, setCode] = useState<string>('-- Enter your Lua script here\nprint("Hello World")');
  const [obfuscatedCode, setObfuscatedCode] = useState<string>("");
  const [editorMounted, setEditorMounted] = useState(false);
  const [options, setOptions] = useState<Omit<ObfuscationOptions, 'code'>>({
    renameVariables: true,
    renameGlobals: false,
    encryptStrings: true,
    constantPooling: true,
    controlFlowFlattening: false,
    junkCodeInsertion: false,
    antiTamper: false,
    debugProtection: false,
    virtualize: false,
  });

  const { mutate: obfuscate, isPending, data: result } = useObfuscate();
  const { data: globalStats } = useObfuscationStats();
  const { toast } = useToast();

  const handleEditorDidMount: OnMount = (editor) => {
    setEditorMounted(true);
  };

  const handleObfuscate = () => {
    if (!code.trim()) {
      toast({
        title: "INPUT REQUIRED",
        description: "Please enter Lua code to obfuscate.",
        variant: "destructive",
      });
      return;
    }

    obfuscate({ ...options, code });
  };

  // Update local state when result comes back
  React.useEffect(() => {
    if (result) {
      setObfuscatedCode(result.obfuscatedCode);
      toast({
        title: "OBFUSCATION COMPLETE",
        description: `Code protected. Size increase: ${((result.stats.obfuscatedSize / result.stats.originalSize) * 100).toFixed(0)}%`,
        className: "bg-primary/10 border-primary text-primary font-mono",
      });
    }
  }, [result, toast]);

  const handleDownload = () => {
    if (!obfuscatedCode) return;
    const blob = new Blob([obfuscatedCode], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "protected_script.lua";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) setCode(content);
    };
    reader.readAsText(file);
  };

  const setOption = (key: keyof typeof options) => (val: boolean) => {
    setOptions(prev => ({ ...prev, [key]: val }));
  };

  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden flex flex-col">
      <div className="scanline" />
      
      {/* Header */}
      <header className="border-b border-primary/20 bg-background/95 backdrop-blur z-10 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-primary/10 border border-primary rounded-sm">
            <Terminal className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h1 className="text-xl tracking-widest text-white">IRON<span className="text-primary">LUA</span></h1>
            <p className="text-xs text-muted-foreground font-mono tracking-wider">ADVANCED OBFUSCATION SUITE v1.0</p>
          </div>
        </div>

        <div className="flex gap-6 hidden md:flex">
          <StatCard 
            label="Total Protected" 
            value={globalStats?.totalObfuscations.toLocaleString() || "0"} 
            className="py-1 px-3 border-none bg-transparent" 
          />
          <StatCard 
            label="Bytes Secured" 
            value={globalStats ? (globalStats.totalBytesProtected / 1024).toFixed(1) + ' KB' : "0 KB"} 
            className="py-1 px-3 border-none bg-transparent" 
          />
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        
        {/* Editor Area */}
        <div className="flex-1 flex flex-col relative overflow-hidden">
          
          {/* Top Panel: Configuration (Horizontal) */}
          <div className="h-48 shrink-0 bg-slate-950/80 border-b border-primary/20 overflow-x-auto overflow-y-hidden flex items-stretch gap-6 p-4">
            <div className="flex flex-col gap-2 min-w-[200px]">
              <h2 className="text-[10px] font-mono text-primary/60 flex items-center gap-2 uppercase tracking-tighter">
                <Code2 className="w-3 h-3" /> Core
              </h2>
              <div className="grid grid-cols-2 gap-x-4 gap-y-1">
                <OptionToggle id="rename-vars" label="Rename Vars" checked={options.renameVariables} onCheckedChange={setOption("renameVariables")} />
                <OptionToggle id="rename-globals" label="Rename Globals" checked={options.renameGlobals} onCheckedChange={setOption("renameGlobals")} />
                <OptionToggle id="encrypt-strings" label="Encrypt Strings" checked={options.encryptStrings} onCheckedChange={setOption("encryptStrings")} />
                <OptionToggle id="const-pool" label="Constant Pool" checked={options.constantPooling} onCheckedChange={setOption("constantPooling")} />
              </div>
            </div>

            <div className="w-px bg-primary/10 mx-2" />

            <div className="flex flex-col gap-2 min-w-[150px]">
              <h2 className="text-[10px] font-mono text-primary/60 flex items-center gap-2 uppercase tracking-tighter">
                <Layers className="w-3 h-3" /> Structure
              </h2>
              <div className="flex flex-col gap-1">
                <OptionToggle id="flow-flat" label="Control Flow" checked={options.controlFlowFlattening} onCheckedChange={setOption("controlFlowFlattening")} />
                <OptionToggle id="junk-code" label="Junk Code" checked={options.junkCodeInsertion} onCheckedChange={setOption("junkCodeInsertion")} />
              </div>
            </div>

            <div className="w-px bg-primary/10 mx-2" />

            <div className="flex flex-col gap-2 min-w-[300px]">
              <h2 className="text-[10px] font-mono text-destructive/60 flex items-center gap-2 uppercase tracking-tighter">
                <Shield className="w-3 h-3" /> Security
              </h2>
              <div className="grid grid-cols-2 gap-x-4 gap-y-1">
                <OptionToggle id="anti-tamper" label="Anti-Tamper" checked={options.antiTamper} onCheckedChange={setOption("antiTamper")} />
                <OptionToggle id="debug-prot" label="Anti-Debug" checked={options.debugProtection} onCheckedChange={setOption("debugProtection")} />
                <OptionToggle id="vm-mode" label="Virtual Machine" checked={options.virtualize} onCheckedChange={setOption("virtualize")} />
              </div>
            </div>

            <div className="flex-1 flex items-center justify-end px-4">
              <CyberButton 
                onClick={handleObfuscate} 
                isLoading={isPending}
                className="shadow-2xl shadow-primary/20 text-lg py-6 px-10 h-16"
                icon={<Zap className="w-6 h-6" />}
              >
                OBFUSCATE
              </CyberButton>
            </div>
          </div>

          {/* Bottom Panel: Editors (Side by Side) */}
          <div className="flex-1 flex flex-col md:flex-row relative overflow-hidden min-h-[600px]">
            {/* Input Panel */}
            <div className="flex-1 flex flex-col border-r border-primary/10 relative group">
              <div className="bg-slate-900 border-b border-primary/10 px-4 py-1.5 flex justify-between items-center">
                <span className="text-[10px] font-mono text-muted-foreground flex items-center gap-2">
                  <Code2 className="w-3 h-3 text-primary" /> INPUT.lua
                </span>
                <div className="flex items-center gap-4">
                  <input type="file" id="lua-file-upload" className="hidden" accept=".lua,.txt" onChange={handleFileUpload} />
                  <label htmlFor="lua-file-upload" className="text-[9px] text-primary/80 hover:text-primary font-mono cursor-pointer border border-primary/20 px-2 py-0.5 rounded transition-colors uppercase">
                    Load Script
                  </label>
                </div>
              </div>
              <div className="flex-1 relative">
                <Editor
                  height="100%"
                  defaultLanguage="lua"
                  theme="vs-dark"
                  value={code}
                  onChange={(val) => setCode(val || "")}
                  onMount={handleEditorDidMount}
                  options={{
                    fontFamily: "'JetBrains Mono', monospace",
                    fontSize: 14,
                    minimap: { enabled: true },
                    scrollBeyondLastLine: false,
                    padding: { top: 12 },
                    cursorBlinking: "phase",
                    cursorStyle: "block",
                    automaticLayout: true,
                  }}
                />
              </div>
            </div>

            {/* Output Panel */}
            <div className={cn(
              "flex-1 flex flex-col bg-black/40 relative", 
              isPending && "opacity-50 pointer-events-none"
            )}>
              <div className="bg-slate-900 border-b border-primary/10 px-4 py-1.5 flex justify-between items-center">
                <span className="text-[10px] font-mono text-muted-foreground flex items-center gap-2">
                  <Lock className="w-3 h-3 text-primary" /> OUTPUT.lua
                </span>
                <div className="flex items-center gap-2">
                  {result && (
                    <span className="text-[9px] text-primary font-mono bg-primary/10 px-2 py-0.5 rounded">
                      {(result.stats.obfuscatedSize / 1024).toFixed(2)} KB
                    </span>
                  )}
                </div>
              </div>
              
              <div className="flex-1 relative">
                {isPending && (
                  <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-background/80 backdrop-blur-[2px]">
                     <div className="flex flex-col items-center gap-4">
                       <RefreshCw className="w-10 h-10 text-primary animate-spin" />
                       <div className="text-center font-mono">
                         <p className="text-primary font-bold animate-pulse text-sm">ENCRYPTING...</p>
                       </div>
                     </div>
                  </div>
                )}
                
                <Editor
                  height="100%"
                  defaultLanguage="lua"
                  theme="vs-dark"
                  value={obfuscatedCode}
                  options={{
                    readOnly: true,
                    fontFamily: "'JetBrains Mono', monospace",
                    fontSize: 14,
                    minimap: { enabled: true },
                    scrollBeyondLastLine: false,
                    domReadOnly: true,
                    padding: { top: 12 },
                    automaticLayout: true,
                  }}
                />
              </div>

              {/* Result Actions */}
              <AnimatePresence>
                {obfuscatedCode && (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="absolute bottom-6 right-6 z-10 flex gap-2"
                  >
                    <CyberButton 
                      variant="secondary"
                      size="sm"
                      onClick={() => {
                        navigator.clipboard.writeText(obfuscatedCode);
                        toast({ title: "COPIED", description: "Script copied to clipboard." });
                      }}
                    >
                      COPY
                    </CyberButton>
                    <CyberButton 
                      size="sm"
                      onClick={handleDownload}
                      icon={<Download className="w-4 h-4" />}
                    >
                      DOWNLOAD
                    </CyberButton>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </main>

      {/* Decorative footer line */}
      <div className="h-1 w-full bg-gradient-to-r from-transparent via-primary/30 to-transparent" />
    </div>
  );
}
