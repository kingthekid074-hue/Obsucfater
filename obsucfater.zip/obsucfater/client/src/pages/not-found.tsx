import { Link } from "wouter";
import { AlertTriangle } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background text-foreground relative overflow-hidden">
      <div className="scanline" />
      
      <div className="max-w-md w-full p-8 border border-destructive/30 bg-card/50 backdrop-blur-md rounded-lg shadow-2xl relative">
        <div className="absolute -top-3 -left-3 w-6 h-6 border-t-2 border-l-2 border-destructive" />
        <div className="absolute -bottom-3 -right-3 w-6 h-6 border-b-2 border-r-2 border-destructive" />
        
        <div className="flex flex-col items-center text-center space-y-6">
          <div className="p-4 rounded-full bg-destructive/10 border border-destructive/20 animate-pulse">
            <AlertTriangle className="w-12 h-12 text-destructive" />
          </div>
          
          <div className="space-y-2">
            <h1 className="text-4xl font-display font-bold text-destructive">404 ERROR</h1>
            <p className="text-muted-foreground font-mono">
              TARGET SECTOR NOT FOUND OR ACCESS DENIED.
            </p>
          </div>

          <Link href="/" className="px-6 py-3 bg-destructive/10 border border-destructive text-destructive hover:bg-destructive hover:text-white transition-all font-mono font-bold uppercase tracking-widest text-sm">
            Return to Base
          </Link>
        </div>
      </div>
    </div>
  );
}
