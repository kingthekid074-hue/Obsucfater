# replit.md

## Overview

This is a **Lua Code Obfuscator** web application with a cybersecurity/hacker-themed UI. Users paste Lua code into a Monaco editor, configure obfuscation options (variable renaming, string encryption, control flow flattening, virtualization, etc.), and receive obfuscated output. The app tracks anonymized usage statistics in a PostgreSQL database.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend
- **Framework**: React 18 with TypeScript, bundled by Vite
- **Routing**: Wouter (lightweight client-side router) — single main page at `/`
- **State/Data Fetching**: TanStack React Query for server communication
- **UI Components**: shadcn/ui (new-york style) built on Radix UI primitives with Tailwind CSS
- **Code Editor**: Monaco Editor (`@monaco-editor/react`) for Lua code input/output
- **Animations**: Framer Motion for "hacking" visual effects
- **Theme**: Dark cybersecurity theme with neon green (`#00ff41`) on deep dark backgrounds. Fonts: Inter (sans), JetBrains Mono (mono), Space Grotesk (display)
- **Path aliases**: `@/` → `client/src/`, `@shared/` → `shared/`

### Backend
- **Framework**: Express.js running on Node with TypeScript (via tsx)
- **API Design**: Contract-first approach — API routes, input validation (Zod), and response schemas defined in `shared/routes.ts` and `shared/schema.ts`
- **Core Service**: `LuaObfuscator` class in `server/services/obfuscation.ts` that parses Lua (using `luaparse`), transforms the AST, and regenerates code
- **Development**: Vite dev server middleware with HMR served through Express
- **Production**: Vite builds static assets to `dist/public`, esbuild bundles server to `dist/index.cjs`

### API Endpoints
- `POST /api/obfuscate` — Accepts Lua code + obfuscation options, returns obfuscated code with size/timing stats
- `GET /api/stats` — Returns aggregate usage statistics (total obfuscations, bytes protected)

### Obfuscation Features
Options are defined in `obfuscationOptionsSchema`:
- **Core**: Variable renaming, global renaming, string encryption, constant pooling
- **Advanced**: Control flow flattening, junk code insertion
- **Protection**: Anti-tamper, debug protection
- **Virtualization**: VM-based code transformation

### Database
- **PostgreSQL** via `node-postgres` (`pg` Pool)
- **ORM**: Drizzle ORM with Drizzle-Zod for schema-to-validation integration
- **Schema** (in `shared/schema.ts`): Single table `obfuscation_stats` tracking features used, input/output sizes, and timestamps. No user code is stored.
- **Migrations**: Managed via `drizzle-kit push` (schema push approach, not migration files)
- **Config**: `drizzle.config.ts` reads `DATABASE_URL` from environment

### Shared Code
The `shared/` directory contains code used by both client and server:
- `schema.ts` — Database schema + Zod validation schemas for API contracts
- `routes.ts` — API route definitions with paths, methods, input/output types

### Build System
- `script/build.ts` handles production builds: Vite for client, esbuild for server
- Server dependencies are selectively bundled (allowlist in build script) to reduce cold start times
- Dev: `tsx server/index.ts` with Vite middleware
- Prod: `node dist/index.cjs` serving static files

## External Dependencies

### Database
- **PostgreSQL** — Required. Connection via `DATABASE_URL` environment variable. Uses `connect-pg-simple` for session storage capability and `pg` Pool for direct connections.

### Key NPM Packages
- `luaparse` — Lua code parsing into AST (critical for obfuscation engine)
- `drizzle-orm` + `drizzle-kit` — Database ORM and schema management
- `@monaco-editor/react` — In-browser code editor
- `framer-motion` — Animation library for UI effects
- `zod` + `drizzle-zod` — Runtime validation and schema-to-type generation
- `wouter` — Client-side routing
- `@tanstack/react-query` — Server state management
- shadcn/ui ecosystem: Radix UI primitives, Tailwind CSS, class-variance-authority, clsx, tailwind-merge, lucide-react icons

### External Services
- Google Fonts (Inter, JetBrains Mono, Space Grotesk, Fira Code, Geist Mono, DM Sans, Architects Daughter) loaded via CDN
- No external APIs or third-party services beyond the database