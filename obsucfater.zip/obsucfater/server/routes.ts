import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { LuaObfuscator } from "./services/obfuscation";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.post(api.obfuscator.process.path, async (req, res) => {
    try {
      const start = Date.now();
      const input = api.obfuscator.process.input.parse(req.body);
      
      const obfuscator = new LuaObfuscator(input.code, input);
      const obfuscatedCode = obfuscator.obfuscate();
      
      const end = Date.now();
      const inputSize = Buffer.byteLength(input.code, 'utf8');
      const outputSize = Buffer.byteLength(obfuscatedCode, 'utf8');
      
      // Log async
      storage.logObfuscation(input, inputSize, outputSize).catch(console.error);
      
      res.json({
        obfuscatedCode,
        stats: {
          originalSize: inputSize,
          obfuscatedSize: outputSize,
          obfuscationTimeMs: end - start
        }
      });
    } catch (err) {
      console.error('Obfuscation error:', err);
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: "Validation failed",
          details: err.errors
        });
      }
      res.status(500).json({ 
        message: "Failed to obfuscate code. Syntax error in input Lua or internal error.",
        error: String(err)
      });
    }
  });

  app.get(api.obfuscator.stats.path, async (req, res) => {
    const stats = await storage.getStats();
    res.json(stats);
  });

  return httpServer;
}
