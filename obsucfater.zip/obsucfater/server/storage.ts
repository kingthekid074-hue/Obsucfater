import { db } from "./db";
import { obfuscationStats, type ObfuscationOptions } from "@shared/schema";
import { eq, sql } from "drizzle-orm";

export interface IStorage {
  logObfuscation(options: ObfuscationOptions, inputSize: number, outputSize: number): Promise<void>;
  getStats(): Promise<{ totalObfuscations: number, totalBytesProtected: number }>;
}

export class DatabaseStorage implements IStorage {
  async logObfuscation(options: ObfuscationOptions, inputSize: number, outputSize: number): Promise<void> {
    const features = Object.entries(options)
      .filter(([key, value]) => value === true && key !== 'code')
      .map(([key]) => key);

    await db.insert(obfuscationStats).values({
      featuresUsed: features,
      inputSize,
      outputSize,
    });
  }

  async getStats(): Promise<{ totalObfuscations: number, totalBytesProtected: number }> {
    const result = await db.select({
      count: sql<number>`count(*)`,
      bytes: sql<number>`sum(${obfuscationStats.inputSize})`
    }).from(obfuscationStats);

    return {
      totalObfuscations: Number(result[0]?.count || 0),
      totalBytesProtected: Number(result[0]?.bytes || 0)
    };
  }
}

export const storage = new DatabaseStorage();
