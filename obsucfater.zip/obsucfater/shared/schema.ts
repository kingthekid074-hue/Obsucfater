import { pgTable, text, serial, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// We'll track usage statistics (no sensitive code storage)
export const obfuscationStats = pgTable("obfuscation_stats", {
  id: serial("id").primaryKey(),
  featuresUsed: jsonb("features_used").notNull(), // Array of enabled features
  inputSize: serial("input_size"),
  outputSize: serial("output_size"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertStatsSchema = createInsertSchema(obfuscationStats);

// === API CONTRACT TYPES ===

export const obfuscationOptionsSchema = z.object({
  // Core Features
  renameVariables: z.boolean().default(true),
  renameGlobals: z.boolean().default(false),
  encryptStrings: z.boolean().default(true),
  constantPooling: z.boolean().default(true),
  
  // Advanced Features
  controlFlowFlattening: z.boolean().default(false),
  junkCodeInsertion: z.boolean().default(false),
  
  // Protection
  antiTamper: z.boolean().default(false),
  debugProtection: z.boolean().default(false),
  
  // Virtualization (The "VM" feature)
  virtualize: z.boolean().default(false),
  
  // Code Input
  code: z.string().min(1, "Lua code is required"),
});

export type ObfuscationOptions = z.infer<typeof obfuscationOptionsSchema>;

export const obfuscationResponseSchema = z.object({
  obfuscatedCode: z.string(),
  stats: z.object({
    originalSize: z.number(),
    obfuscatedSize: z.number(),
    obfuscationTimeMs: z.number(),
  }),
});

export type ObfuscationResponse = z.infer<typeof obfuscationResponseSchema>;
